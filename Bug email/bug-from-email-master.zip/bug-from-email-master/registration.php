<?php
/**
 * @author     Sashas IT Support <support@sashas.org>
 * @copyright  2018  Sashas IT Support Inc. (http://www.extensions.sashas.org)
 * @license     http://opensource.org/licenses/GPL-3.0  GNU General Public License, version 3 (GPL-3.0)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sashas_BugFromEmail',
    __DIR__
);
